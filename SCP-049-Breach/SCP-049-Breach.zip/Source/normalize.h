#include <SFML\Graphics.hpp>
sf::Vector2f normalize(const sf::Vector2f&);