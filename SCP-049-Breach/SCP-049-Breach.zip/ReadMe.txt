
SCP-049-Breach
=================

Target
------
Find the Keycard and escape!

Enemies
--------
The Zombies only see you when you are in front of them. They will chase and attack you until they can't see you any more.
You can kill them with one hit but be careful: they can hit you too!

Controls
---------
WASD        -   Moving
Mouse       -   Rotation
LeftClick   -   Toggle Flashlight
RightClick  -   Attack
MouseWheel  -   Zooming
ESC         -   Exit

Alpha Limitations
------------------
    #   Please stay in the upper half of the Level (where the concrete paths are), the Key and Zombies only spawn there
    #   Some shadows are missing
    #   Zombies and Key can spawn inside each other or inside object -> please restart, sry
    #   Some collisions are weird
    